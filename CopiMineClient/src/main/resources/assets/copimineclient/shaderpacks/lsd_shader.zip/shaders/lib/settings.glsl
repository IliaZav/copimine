// LSD_Sshader v1.2.2 — clean-room core settings (Iris/OptiFine)
//
// Notes:
// - All options are defined exactly once (no include guards) to avoid Iris parser crashes.
// - Slider lists use the OptiFine/Iris format: // [a b c ...]

#define LSD_ENABLE 1                    // [0 1]
#define LSD_INTENSITY 1.75              // [0.0 0.35 0.75 1.0 1.35 1.75 2.2 2.8]

// Color grade
#define LSD_EXPOSURE 1.10               // [0.70 0.85 1.00 1.10 1.22 1.35]
#define LSD_SATURATION 1.45             // [0.80 1.00 1.18 1.45 1.65 1.90]
#define LSD_CONTRAST 1.08               // [0.90 1.00 1.08 1.18 1.35]
#define LSD_BLOOM 0.40                  // [0.0 0.10 0.18 0.40 0.55 0.80]
#define LSD_VIGNETTE 0.10               // [0.0 0.06 0.10 0.16 0.25]

// Motion hallucinations
#define LSD_WARP 0.62                   // [0.0 0.15 0.30 0.62 0.90 1.20]
#define LSD_RUN_DRIFT 0.95              // [0.0 0.25 0.45 0.95 1.30]
#define LSD_SHAKE 0.60                  // [0.0 0.20 0.35 0.60 0.85 1.20]
#define LSD_SHAKE_INTERVAL 12.0         // [6.0 10.0 12.0 16.0 24.0 36.0]
#define LSD_AFTERIMAGE 0.60             // [0.0 0.18 0.35 0.60 0.80 1.0]
#define LSD_CHROMA 0.45                 // [0.0 0.18 0.30 0.45 0.65 0.90]

// Light hallucinations
#define LSD_EMISSIVE_RAINBOW 1.00       // [0.0 0.25 0.5 0.75 1.0]
#define LSD_LIGHT_CYCLE_SPEED 1.75      // [0.2 0.5 0.8 1.0 1.75 2.6 3.6]
#define LSD_RED_REDUCE 0.30             // [0.0 0.15 0.25 0.30 0.45 0.70]

// Sky / Clouds
#define LSD_CLOUDS 1                    // [0 1]
#define LSD_CLOUD_DENSITY 0.64          // [0.25 0.45 0.64 0.80 0.98]
#define LSD_CLOUD_SWIRL 0.80            // [0.0 0.25 0.5 0.80 1.10]
#define LSD_SKY_RGB_SHIFT 1.30          // [0.0 0.3 0.6 1.30 1.9 2.6]
#define LSD_BIG_SUN_MOON 1              // [0 1]
#define LSD_SMILE_SKY 1                 // [0 1]
#define LSD_STARS 1.55                  // [0.0 0.5 1.0 1.55 2.2 3.2]

// Better sun / moon (v1.2+)
#define LSD_SUN_SIZE 0.020              // [0.010 0.016 0.020 0.026 0.034]
#define LSD_SUN_HALO 0.30               // [0.10 0.18 0.30 0.45 0.65]
#define LSD_MOON_SIZE 0.018             // [0.010 0.014 0.018 0.024 0.030]
#define LSD_MOON_HALO 0.36              // [0.12 0.22 0.36 0.55 0.80]
#define LSD_SUNRAYS 0.60                // [0.0 0.18 0.30 0.60 0.85 1.10]

// Shadows (cheap screen-space sun shadows)
#define LSD_SUN_SHADOWS 1               // [0 1]
#define LSD_SHADOW_STRENGTH 0.62        // [0.0 0.25 0.40 0.62 0.78 0.95]
#define LSD_SHADOW_LENGTH 0.80          // [0.25 0.45 0.60 0.80 1.05 1.35]

// Weather / haze
#define LSD_HAZE 0.20                   // [0.0 0.08 0.12 0.20 0.30 0.45]

// Overlay hallucination (custom image)
#define LSD_OVERLAY_ENABLE 1            // [0 1]
#define LSD_OVERLAY_CHANCE 0.06         // [0.0 0.02 0.04 0.06 0.10 0.16]
#define LSD_OVERLAY_INTERVAL 60.0       // [20.0 30.0 45.0 60.0 90.0 120.0]
#define LSD_OVERLAY_DURATION 0.70       // [0.15 0.30 0.50 0.70 1.00 1.50]
#define LSD_OVERLAY_ALPHA 0.55          // [0.15 0.30 0.45 0.55 0.70 0.90]
#define LSD_OVERLAY_SCALE 1.00          // [0.5 0.75 1.0 1.25 1.6 2.2]

// Symptoms
#define LSD_PATTERN_GRID 0.42           // [0.0 0.15 0.25 0.42 0.60 0.90]
#define LSD_FLOATERS 0.50               // [0.0 0.18 0.30 0.50 0.75 1.0]
#define LSD_BREATHING 0.60              // [0.0 0.25 0.40 0.60 0.85 1.0]
#define LSD_SHADOW_FIGURES 0.60         // [0.0 0.2 0.35 0.60 0.80 1.0]

// Dimensions
#define LSD_NETHER_LIFT 0.34            // [0.0 0.12 0.20 0.34 0.48 0.65]
#define LSD_END_AURORA 0.60             // [0.0 0.25 0.4 0.60 0.85 1.2]
