#version 330 compatibility
uniform sampler2D texture;
uniform float frameTimeCounter;
in vec2 vTex;
in vec4 vColor;
layout(location=0) out vec4 outColor;

#include "/lib/noise.glsl"
#include "/lib/math.glsl"
#include "/lib/settings.glsl"

void main(){
    vec4 c = texture(texture, vTex) * vColor;
    float t = frameTimeCounter;
    float n = fbm(vTex*vec2(16.0,12.0) + vec2(t*0.02, -t*0.015));
    float s = smoothstep(0.55, 0.95, n);
    vec3 tint = mix(vec3(0.70,0.85,1.25), vec3(1.10,0.65,1.05), 0.5 + 0.5*sin(t*0.2));
    c.rgb = mix(c.rgb, c.rgb * tint, 0.25);
    c.rgb += vec3(0.10, 0.12, 0.14) * s * 0.18;
    outColor = c;
}
