// Uniforms provided by shader pipeline
uniform float frameTimeCounter;
uniform int worldTime;
uniform float rainStrength;
uniform vec3 sunPosition;

float dayFactor(){
    float t = fract(float(worldTime) / 24000.0);
    return smoothstep(0.22, 0.30, t) * (1.0 - smoothstep(0.70, 0.78, t));
}

vec3 skyBase(vec3 ray, float day, float horizon, float rain){
    // psychedelic sky palette (unique signature)
    vec3 dayLow = vec3(0.90, 0.78, 1.12);
    vec3 dayHigh = vec3(0.25, 0.65, 1.20);

    vec3 duskLow = vec3(1.08, 0.76, 0.50);
    vec3 duskHigh = vec3(0.95, 0.30, 1.05);

    vec3 nightLow = vec3(0.02, 0.01, 0.05);
    vec3 nightHigh = vec3(0.12, 0.04, 0.22);

    float y = sat(ray.y*0.70 + 0.30);
    vec3 baseDay = mix(dayLow, dayHigh, y);
    vec3 baseDusk = mix(duskLow, duskHigh, y);
    vec3 baseNight = mix(nightLow, nightHigh, y);

    float duskMix = smoothstep(0.10, 0.60, abs(day - 0.5) * 2.0);
    vec3 base = mix(baseDusk, baseDay, duskMix);
    base = mix(baseNight, base, day);

    // subtle nebula noise
    vec2 uv = ray.xz / max(0.1, (0.55 + ray.y));
    float n = fbm(uv*0.75 + frameTimeCounter*0.005);
    base += vec3(0.18, 0.08, 0.22) * smoothstep(0.72, 0.96, n) * (0.12 + 0.18*(1.0-day));

    // horizon tint
    base += vec3(0.10, 0.02, 0.08) * horizon * (0.10 + 0.08*(1.0-day));

    // rain: desaturate/cool
    base = mix(base, vec3(luma(base)), rain*0.60);
    base = mix(base, base * vec3(0.78, 0.84, 0.92), rain*0.55);
    return base;
}

vec3 stars(vec2 uv, float night, float rain){
    float s1 = smoothstep(0.985, 0.999, n2(uv * 140.0 + 0.17));
    float s2 = smoothstep(0.97, 0.999, n2(uv * 240.0 + 0.43));
    float tw = 0.65 + 0.35 * sin(frameTimeCounter * 2.4 + uv.x * 90.0 + uv.y * 70.0);
    float m = (s1 * 0.7 + s2 * 0.3) * tw;
    return vec3(0.80, 0.90, 1.10) * m * night * LSD_STARS * 0.18 * (1.0 - rain*0.75);
}

void sunMoon(in vec3 ray, out vec3 add){
    vec3 sDir = normalize(sunPosition);
    float sd = dot(ray, sDir);
    float md = dot(ray, -sDir);

    float sunSize = (LSD_BIG_SUN_MOON > 0 ? LSD_SUN_SIZE : LSD_SUN_SIZE*0.70);
    float moonSize = (LSD_BIG_SUN_MOON > 0 ? LSD_MOON_SIZE : LSD_MOON_SIZE*0.70);

    float sunCore = smoothstep(1.0 - sunSize, 1.0, sd);
    float sunHalo = smoothstep(1.0 - sunSize*(10.0 + 10.0*LSD_SKY_RGB_SHIFT + 10.0*LSD_SUN_HALO), 1.0, sd) * (0.12 + 0.10*LSD_SUN_HALO);

    float moonCore = smoothstep(1.0 - moonSize, 1.0, md);
    float moonHalo = smoothstep(1.0 - moonSize*(12.0 + 12.0*LSD_SKY_RGB_SHIFT + 10.0*LSD_MOON_HALO), 1.0, md) * (0.12 + 0.12*LSD_MOON_HALO);

    float t = frameTimeCounter * 0.35;
    vec3 rgb = 0.5 + 0.5*sin(vec3(0.0,2.09,4.18) + t);
    vec3 sunCol = mix(vec3(1.25, 0.95, 0.75), vec3(0.85, 0.65, 1.20), rgb.r);
    vec3 moonCol = mix(vec3(0.75, 0.90, 1.25), vec3(1.10, 0.55, 1.10), rgb.g);

    add = sunCol * (sunCore*1.30 + sunHalo) + moonCol * (moonCore*0.95 + moonHalo);

    // Smiley face overlay (stylized)
    if(LSD_SMILE_SKY > 0){
        vec3 up = abs(sDir.y) > 0.9 ? vec3(0.0,0.0,1.0) : vec3(0.0,1.0,0.0);
        vec3 u = normalize(cross(up, sDir));
        vec3 v = cross(sDir, u);
        float denom = max(1.0 - sd, 0.0002);
        vec2 sc = vec2(dot(ray, u), dot(ray, v)) / denom;

        float face = smoothstep(0.62, 0.08, length(sc));
        float e1 = smoothstep(0.12, 0.06, length(sc - vec2(-0.18, 0.12)));
        float e2 = smoothstep(0.12, 0.06, length(sc - vec2( 0.18, 0.12)));
        vec2 mpos = sc - vec2(0.0, -0.06);
        float smile = smoothstep(0.06, 0.02, abs(length(mpos * vec2(1.0, 1.35)) - 0.22));
        smile *= smoothstep(-0.08, 0.10, sc.y);

        vec3 smileCol = 0.5 + 0.5*sin(vec3(0.0,2.09,4.18) + frameTimeCounter*0.7);
        add += smileCol * (0.10*face + 0.35*(e1+e2) + 0.30*smile) * sunHalo * 1.20;
    }

// Sunrays (stylized radial god-rays) - clean-room
if(LSD_SUNRAYS > 0.001){
    float rays = pow(clamp(sd, 0.0, 1.0), 120.0);
    float spoke = 0.5 + 0.5*sin((ray.x*28.0 + ray.y*15.0 + ray.z*22.0) * 2.8 + frameTimeCounter*0.35);
    float rayMask = rays * (0.35 + 0.65*spoke) * LSD_SUNRAYS;
    add += (sunCol * (0.08 + 0.12*LSD_SKY_RGB_SHIFT)) * rayMask;
}
}
