#version 330 compatibility
uniform sampler2D colortex0;
uniform sampler2D depthtex0;
uniform sampler2D lsdOverlay;

uniform float frameTimeCounter;
uniform float rainStrength;
uniform float viewWidth;
uniform float viewHeight;
uniform vec3 cameraPosition;
uniform vec3 previousCameraPosition;

in vec2 vTex;
layout(location=0) out vec4 outColor;

#include "/lib/settings.glsl"
#include "/lib/math.glsl"
#include "/lib/noise.glsl"

float hash12(vec2 p){
  vec3 p3 = fract(vec3(p.xyx) * 0.1031);
  p3 += dot(p3, p3.yzx + 33.33);
  return fract((p3.x + p3.y) * p3.z);
}


float sunShadowSS(vec2 uv, float depth, vec2 sunDir, float strength, float len){
    float occ = 0.0;
    vec2 dir = normalize(sunDir + vec2(1e-5)) * (0.002 + 0.010 * len);
    for(int i=1;i<=10;i++){
        float tt = float(i)/10.0;
        vec2 p = clamp(uv + dir * tt, vec2(0.001), vec2(0.999));
        float d = texture(depthtex0, p).r;
        occ += step(d + 0.002, depth) * (1.0 - tt);
    }
    occ = occ / 10.0;
    return clamp(1.0 - occ * strength, 0.15, 1.0);
}

vec3 bloom9(vec2 uv){
    vec2 px = vec2(1.0/viewWidth, 1.0/viewHeight);
    vec3 s = vec3(0.0);
    s += texture(colortex0, uv + px*vec2(-1.0,-1.0)).rgb;
    s += texture(colortex0, uv + px*vec2( 0.0,-1.0)).rgb;
    s += texture(colortex0, uv + px*vec2( 1.0,-1.0)).rgb;
    s += texture(colortex0, uv + px*vec2(-1.0, 0.0)).rgb;
    s += texture(colortex0, uv).rgb;
    s += texture(colortex0, uv + px*vec2( 1.0, 0.0)).rgb;
    s += texture(colortex0, uv + px*vec2(-1.0, 1.0)).rgb;
    s += texture(colortex0, uv + px*vec2( 0.0, 1.0)).rgb;
    s += texture(colortex0, uv + px*vec2( 1.0, 1.0)).rgb;
    return s / 9.0;
}

void main(){
    vec2 uv = vTex;
    float t = frameTimeCounter;

    vec3 baseCol0 = texture(colortex0, uv).rgb;
    vec3 col = baseCol0;

// LSD_ENABLE gating: allow disabling the trip while keeping a mild cinematic grade
#if LSD_ENABLE == 0
    col = softContrast(col, 1.02);
    col = saturateColor(col, 1.06);
    col *= 1.02;
    vec3 b0 = bloom9(uv);
    col += b0 * smoothstep(0.60, 2.0, luma(b0)) * 0.08;
    col = tonemap(col);
    vec2 q0 = (uv - 0.5) * vec2(viewWidth/viewHeight, 1.0);
    col *= clamp(1.0 - dot(q0,q0) * 0.08, 0.85, 1.0);
    outColor = vec4(clamp(col,0.0,1.0), 1.0);
    return;
#endif


    float depth = texture(depthtex0, uv).r;
    float skyMask = step(0.999999, depth);
    float sceneMask = 1.0 - skyMask;

// Haze (depth-based)
float haze = smoothstep(0.70, 0.999, depth) * sceneMask * LSD_HAZE;
vec3 hazeCol = 0.5 + 0.5*sin(vec3(0.0,2.09,4.18) + t*0.22 + uv.xyx*vec3(3.0,4.0,5.0));
hazeCol = mix(vec3(0.65,0.62,0.70), hazeCol, 0.55);
col = mix(col, hazeCol, clamp(haze, 0.0, 0.35));


    // Movement speed (for run drift)
    vec3 camDelta = cameraPosition - previousCameraPosition;
    float spd = clamp(length(camDelta), 0.0, 1.6);
    vec2 runDir = normalize(vec2(camDelta.x, camDelta.z) + vec2(1e-5));
    float runAmt = sat(LSD_RUN_DRIFT) * smoothstep(0.002, 0.06, spd);

    // Approx sun screen direction (stylized)
vec2 sunDirSS = normalize(vec2(cos(t*0.08), sin(t*0.08)));

// Warp / swirl
    vec2 p = (uv - 0.5) * vec2(viewWidth/viewHeight, 1.0);
    float r = length(p);

    float warpAmt = 0.0026 * sat(LSD_WARP) * (0.55 + 0.45 * (0.5 + 0.5*sin(t*0.9 + r*18.0)));
    vec2 swirl = vec2(-p.y, p.x) * sin(t*0.7 + r*20.0) * warpAmt;

    vec2 wobble = vec2(
        sin(uv.y*38.0 + t*2.8),
        cos(uv.x*31.0 - t*2.2)
    ) * warpAmt;

    // Running drift: world feels like it keeps moving
    vec2 runOsc = runDir * (0.001 + 0.018 * runAmt) * sin(t*26.0 + uv.y*98.0);
    runOsc += vec2(runDir.y, -runDir.x) * (0.001 + 0.012 * runAmt) * sin(t*19.0 + uv.x*76.0);

    // Shake bursts
    float interval = max(LSD_SHAKE_INTERVAL, 6.0);
    float ph = fract(t / interval);
    float burst = smoothstep(0.00, 0.06, ph) * (1.0 - smoothstep(0.28, 0.40, ph));
    float shake = burst * sat(LSD_SHAKE);
    vec2 shdir = normalize(vec2(sin(t*17.0 + n2(uv*23.0)*6.0), cos(t*13.0 - n2(uv*19.0)*7.0)));
    vec2 shuv = shdir * (0.0012 + 0.0060*shake) * (0.55 + 0.45*sin(t*22.0));

    vec2 uvWarp = clamp(uv + swirl + wobble + runOsc + shuv, vec2(0.001), vec2(0.999));

    // Chromatic aberration
    float chroma = sat(LSD_CHROMA) * (0.0006 + 0.0022 * (0.5 + 0.5*sin(t*1.2 + r*16.0)));
    vec2 cOff = vec2(chroma, -chroma);

    vec3 sR = texture(colortex0, clamp(uvWarp + cOff, vec2(0.001), vec2(0.999))).rgb;
    vec3 sG = texture(colortex0, uvWarp).rgb;
    vec3 sB = texture(colortex0, clamp(uvWarp - cOff, vec2(0.001), vec2(0.999))).rgb;
    vec3 warped = vec3(sR.r, sG.g, sB.b);

    // mix warp into scene
    float warpMix = sat(0.10 + 0.60*sat(LSD_WARP) + 0.35*runAmt + 0.45*shake);
    col = mix(col, warped, warpMix);

    // Afterimage
    float aft = sat(LSD_AFTERIMAGE);
    if(aft > 0.001){
        vec2 ghostOff = (runDir * 0.004 + vec2(-runDir.y, runDir.x) * 0.003) * (0.25 + 0.75*aft) * (0.35 + 0.65*runAmt);
        vec3 ghost = texture(colortex0, clamp(uv + ghostOff, vec2(0.001), vec2(0.999))).rgb;
        col = mix(col, ghost, aft * (0.12 + 0.18*runAmt));
    }

    // Sun shadows (cheap screen-space)
#if LSD_SUN_SHADOWS == 1
  float sh = sunShadowSS(uvWarp, depth, sunDirSS, LSD_SHADOW_STRENGTH, LSD_SHADOW_LENGTH);
  col *= mix(1.0, sh, sceneMask);
#endif

// Bloom
    vec3 b = bloom9(uv);
    float bLum = luma(b);
    float bMask = smoothstep(0.60, 2.2, bLum);
    col += b * bMask * LSD_BLOOM * 0.22;

    // Trip grade: hue shift + rainbow edge + breathing (LSD_ENABLE gating)
    float lum = luma(col);
    float pulse = 0.5 + 0.5*sin(t*(1.25 + 0.25*LSD_INTENSITY) + r*(18.0 + 6.0*LSD_INTENSITY));
    float wave = sin(p.x*(18.0+6.0*LSD_INTENSITY) + t*(2.6+0.6*LSD_INTENSITY)) * cos(p.y*(14.0+5.0*LSD_INTENSITY) - t*(2.1+0.5*LSD_INTENSITY));
    float tripMix = sat((0.18 + 0.22*pulse + 0.10*wave) * (0.70 + 0.55*LSD_INTENSITY));

    col = hueShift(col, (0.22 + 0.18*pulse + 0.12*wave) * (0.50 + 0.55*LSD_INTENSITY));
    col = saturateColor(col, LSD_SATURATION);
    col = softContrast(col, LSD_CONTRAST);
    col *= LSD_EXPOSURE;

    vec3 rainbow = 0.5 + 0.5*sin(vec3(0.0,2.09,4.18) + t*(1.35 + 0.40*LSD_INTENSITY) + r*(22.0 + 9.0*LSD_INTENSITY) + wave*2.4);
    float edge = clamp(abs(dFdx(lum)) + abs(dFdy(lum))*1.25, 0.0, 1.0);
    col += rainbow * tripMix * (0.04 + 0.14*skyMask) * (0.80 + 0.45*LSD_INTENSITY);

// Pattern grid hallucination
float gridA = abs(fract((uv.x + 0.03*sin(t*0.3))*18.0) - 0.5);
float gridB = abs(fract((uv.y + 0.03*cos(t*0.27))*18.0) - 0.5);
float grid = smoothstep(0.02, 0.0, min(gridA, gridB));
grid *= (0.35 + 0.65*tripMix) * LSD_PATTERN_GRID * (0.40 + 0.60*sceneMask);
vec3 gridCol = 0.5 + 0.5*sin(vec3(0.0,2.09,4.18) + t*0.9 + uv.xyx*vec3(6.0,8.0,7.0));
col += gridCol * grid * 0.10;

// Floaters
float fl = 0.0;
for(int i=0;i<4;i++){
  vec2 p2 = uv*vec2(1.6,1.0) + vec2(float(i)*0.13, float(i)*0.27) + vec2(t*0.02, -t*0.018);
  float nn = n2(p2*15.0);
  fl += smoothstep(0.985, 0.999, nn);
}
fl = clamp(fl, 0.0, 1.0) * LSD_FLOATERS * (0.25 + 0.75*tripMix);
col += vec3(0.85, 0.90, 1.10) * fl * 0.08;

    col += rainbow * smoothstep(0.03, 0.28, edge) * (0.10 + 0.10*LSD_INTENSITY);

    // Emissive RGB cycling (torches/lanterns/glowstone/campfires etc)
    float hi = smoothstep(0.35, 3.2, lum) * sceneMask;
    float warmMask = hi * smoothstep(0.02, 0.18, baseCol0.r - max(baseCol0.g, baseCol0.b));
    float greenMask = hi * smoothstep(0.02, 0.18, baseCol0.g - max(baseCol0.r, baseCol0.b));
    float coolMask = hi * smoothstep(0.02, 0.18, baseCol0.b - max(baseCol0.r, baseCol0.g));
    float glowMask = hi * smoothstep(0.20, 1.00, baseCol0.r) * smoothstep(0.15, 0.95, baseCol0.g);
    float eMask = clamp(max(max(max(warmMask, greenMask), coolMask), glowMask), 0.0, 1.0) * LSD_EMISSIVE_RAINBOW;

    float hueT = t * (0.85*LSD_LIGHT_CYCLE_SPEED) + uv.x*3.0 + uv.y*2.7 + wave*2.2;
    vec3 cyc = hueShift(col, hueT);
    float dimPulse = 0.72 + 0.28*sin(t*(1.2*LSD_LIGHT_CYCLE_SPEED) + r*12.0 + wave);
    cyc *= dimPulse;
    col = mix(col, cyc, eMask * (0.70 + 0.30*LSD_INTENSITY));

    // reduce harsh reds
    float redMask = hi * smoothstep(0.03, 0.25, col.r - max(col.g, col.b));
    col.r *= (1.0 - LSD_RED_REDUCE * redMask);

    // Shadow figures (peripheral)
    if(LSD_SHADOW_FIGURES > 0.001){
        float peri = smoothstep(0.15, 0.55, r);
        float nA = n2(uv*vec2(viewWidth/400.0, viewHeight/400.0) + vec2(t*0.02, -t*0.017));
        float nB = n2(uv*vec2(viewWidth/240.0, viewHeight/240.0) + vec2(-t*0.013, t*0.019));
        float fig = smoothstep(0.93, 0.985, nA) * smoothstep(0.80, 0.99, nB);
        float f = fig * peri * LSD_SHADOW_FIGURES;
        col *= 1.0 - f*0.20;
        col += rainbow * f * 0.06;
    }

    // Breathing exposure symptom
float breath = 0.5 + 0.5*sin(t*0.72);
col *= 1.0 + (breath-0.5) * (0.08*LSD_BREATHING) * (0.25 + 0.75*(1.0 - r));

// Custom overlay hallucination (user texture)
#if LSD_OVERLAY_ENABLE == 1
  float intervalO = max(LSD_OVERLAY_INTERVAL, 5.0);
  float slot = floor(t / intervalO);
  float r0 = hash12(vec2(slot, 7.13));
  float on = step(1.0 - LSD_OVERLAY_CHANCE, r0);
  float phO = fract(t / intervalO);
  float durO = clamp(LSD_OVERLAY_DURATION / intervalO, 0.01, 0.95);
  float wO = smoothstep(0.0, 0.10, phO) * (1.0 - smoothstep(durO, durO+0.10, phO));
  float aO = on * wO * LSD_OVERLAY_ALPHA;
  vec2 ouv = (uv - 0.5) / max(LSD_OVERLAY_SCALE, 0.001) + 0.5;
  vec4 ov = texture(lsdOverlay, clamp(ouv, vec2(0.001), vec2(0.999)));
  vec3 ovRGB = ov.rgb * (0.80 + 0.40*(0.5 + 0.5*sin(t*1.8 + uv.x*10.0)));
  col = mix(col, mix(col, ovRGB, ov.a), aO);
#endif

// Tonemap and vignette
    col = tonemap(col);
    vec2 q = (uv - 0.5) * vec2(viewWidth/viewHeight, 1.0);
    col *= clamp(1.0 - dot(q,q) * LSD_VIGNETTE, 0.82, 1.0);

    outColor = vec4(clamp(col, 0.0, 1.0), 1.0);
}
