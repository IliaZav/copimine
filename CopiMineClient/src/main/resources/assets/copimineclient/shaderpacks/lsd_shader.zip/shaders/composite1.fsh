#version 330 compatibility
uniform sampler2D colortex0;
uniform sampler2D depthtex0;
uniform float viewWidth;
uniform float viewHeight;

in vec2 vTex;
layout(location=0) out vec4 outColor;

#include "/lib/settings.glsl"
#include "/lib/math.glsl"
#include "/lib/noise.glsl"
#include "/lib/reconstruct.glsl"
#include "/lib/sky_lsd.glsl"
#include "/lib/clouds_lsd.glsl"
void main(){
    float d = texture(depthtex0, vTex).r;
    vec3 base = texture(colortex0, vTex).rgb;

    if(d >= 0.999999){
        vec3 ray = viewRayFromTex(vTex);
        float day = dayFactor();
        float night = 1.0 - day;
        float rain = clamp(rainStrength, 0.0, 1.0);

        float horizon = 1.0 - sat(abs(ray.y) * 1.8);
        vec3 sky = skyBase(ray, day, horizon, rain);

        #if LSD_CLOUDS
            float cy = sat(ray.y*0.55 + 0.35);
            float mask = cloudsMask(vTex * vec2(viewWidth/viewHeight, 1.0));
            mask *= (0.75 + 0.25*cy);
            mask *= (1.0 - 0.45*night);
            mask *= (1.0 - 0.22*rain);

            vec3 cCol = cloudsColor(cy, day, rain);
            sky = mix(sky, cCol, clamp(mask, 0.0, 1.0) * 0.62);
            sky += cCol * mask * 0.12;
        #endif

        vec3 sm; sunMoon(ray, sm);
        sky += sm;

        sky += stars(vTex, night, rain);

        // extra rgb drift
        vec3 drift = 0.5 + 0.5*sin(vec3(0.0,2.09,4.18) + frameTimeCounter*0.35 + vTex.xyx*vec3(4.0,6.0,5.0));
        sky = mix(sky, sky*(0.85 + 0.35*drift), clamp(LSD_SKY_RGB_SHIFT*0.10, 0.0, 0.22));

        outColor = vec4(sky, 1.0);
        return;
    }

    outColor = vec4(base, 1.0);
}
