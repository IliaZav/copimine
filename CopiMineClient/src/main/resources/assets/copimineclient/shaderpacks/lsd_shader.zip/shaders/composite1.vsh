#version 330 compatibility
out vec2 vTex;
out vec4 vColor;
void main(){
    vTex = gl_MultiTexCoord0.st;
    vColor = gl_Color;
    gl_Position = gl_ProjectionMatrix * (gl_ModelViewMatrix * gl_Vertex);
}
