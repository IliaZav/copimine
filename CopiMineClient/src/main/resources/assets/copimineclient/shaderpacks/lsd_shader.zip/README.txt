LSD_Sshader v1 (clean-room)
---------------------------
A fully original psychedelic shaderpack built from scratch for Iris/OptiFine.

Highlights:
- Intense hue shifting + rainbow edge glow
- Strong motion hallucinations (warp, run drift, tremor bursts)
- Emissive RGB cycling (torches/lanterns/glowstone/campfires feel alive)
- Psychedelic sky with candy clouds + big sun/moon + smile overlay
- Custom End aurora + readable Nether lift
- Fully configurable in shader options

Tip:
After installing/updating: Reset -> Apply -> Reload Shaders.

Hotfix v1.0.1:
- Removed world0 include wrappers to avoid duplicate #version parsing errors in Iris.
- Added LSD_ENABLE toggle gating in final pass.

v1.1 fix:
- Added include guards to all lib files to prevent duplicate function/uniform definitions.
- Removed duplicate frameTimeCounter uniform from clouds include.
- Improved emissive RGB cycling for bright neutral light sources.

v1.2:
- More settings & UI tabs.
- Better sun/moon controls + sunrays.
- Cheap screen-space sun shadows.
- Depth haze, pattern grid, floaters, breathing.
- User-replaceable overlay texture: shaders/textures/lsd_overlay.png

v1.2.1 fix:
- Removed nested #include chains and include-guards to prevent Iris/OptiFine parser crashes.
- Composite1 now includes math/noise once, sky/cloud libs are pure function libs.
- Tweaked defaults (sunrays, bloom, emissive cycling, shadows).

v1.2.2 fix:
- Fixed Iris 'Range [8, -1)' crash by changing custom texture key to 'texture.final.lsdOverlay'.
- Rebuilt settings.glsl (single defines, no guards) to avoid parser issues.
- Normalized shaders.properties main screen line to 'screen=\' (no space).



Modrinth upload note:
- Renamed top-level folder 'assets/' -> 'extras/' to avoid Modrinth classifying the file as a resource pack.
- These PNGs are optional LUT assets and are not required for runtime.
