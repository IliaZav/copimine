float sat(float x){ return clamp(x, 0.0, 1.0); }
float luma(vec3 c){ return dot(c, vec3(0.2126, 0.7152, 0.0722)); }

vec3 softContrast(vec3 c, float k){
    return (c - 0.5) * k + 0.5;
}

vec3 saturateColor(vec3 c, float s){
    float y = luma(c);
    return mix(vec3(y), c, s);
}

// clean-room tonemap
vec3 tonemap(vec3 x){
    x = max(x, vec3(0.0));
    vec3 a = x * (1.35 + x * 0.18);
    vec3 b = 1.0 + x * (1.55 + x * 0.26);
    return a / b;
}

vec3 hueShift(vec3 c, float a){
    vec3 k = vec3(0.57735026919);
    float ca = cos(a), sa = sin(a);
    return c * ca + cross(k, c) * sa + k * dot(k, c) * (1.0 - ca);
}
