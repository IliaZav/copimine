float cloudField(vec2 uv, float scale, float swirl){
    vec2 p = uv * scale;
    float t = frameTimeCounter * 0.010;
    vec2 w = vec2(
        sin(p.y*0.75 + t*8.5) + sin(p.x*0.45 - t*6.5),
        cos(p.x*0.80 - t*7.8) + cos(p.y*0.55 + t*5.9)
    );
    p += w * swirl * 0.55;
    float f = fbm(p * 0.45);
    float r = ridged(p * 0.85 + vec2(0.12,-0.08));
    return mix(f, r, 0.55);
}

float cloudsMask(vec2 uv){
    float c0 = cloudField(uv + vec2(0.03,-0.01), 2.1, LSD_CLOUD_SWIRL);
    float c1 = cloudField(uv + vec2(-0.07,0.05), 3.3, LSD_CLOUD_SWIRL*1.10);
    float c2 = cloudField(uv + vec2(0.11,0.08), 4.9, LSD_CLOUD_SWIRL*1.25);
    float c = c0*0.62 + c1*0.33 + c2*0.22;
    float dens = LSD_CLOUD_DENSITY;
    c = smoothstep(0.48 - dens*0.30, 0.92, c);
    return c;
}

vec3 cloudsColor(float y, float day, float rain){
    float t = frameTimeCounter*0.18;
    vec3 rgb = 0.5 + 0.5*sin(vec3(0.0,2.09,4.18) + t + y*2.0);

    vec3 base = mix(vec3(1.08, 0.92, 1.02), vec3(0.82, 0.90, 1.12), y);
    vec3 candy = mix(vec3(1.05, 0.70, 1.05), vec3(0.75, 0.85, 1.25), rgb.r);
    vec3 col = mix(base, candy, 0.55 * LSD_SKY_RGB_SHIFT);

    // night tint
    vec3 nightCol = mix(vec3(0.10,0.10,0.16), vec3(0.22,0.12,0.30), y);
    col = mix(nightCol, col, day);

    col = mix(col, vec3(luma(col)), rain*0.72);
    col = mix(col, col*vec3(0.78,0.84,0.92), rain*0.55);
    return col;
}
