uniform mat4 gbufferProjectionInverse;

vec3 viewRayFromTex(vec2 uv){
    vec4 clip = vec4(uv*2.0-1.0, 1.0, 1.0);
    vec4 v = gbufferProjectionInverse * clip;
    return normalize(v.xyz / v.w);
}
