#version 330 compatibility
uniform sampler2D texture;
in vec2 vTex;
in vec4 vColor;
layout(location=0) out vec4 outColor;
void main(){
    outColor = texture(texture, vTex) * vColor;
}
