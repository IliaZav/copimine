uniform sampler2D noisetex;

float n2(vec2 p){
    return texture2D(noisetex, fract(p)).r;
}

float fbm(vec2 p){
    float f = 0.0;
    float a = 0.52;
    mat2 m = mat2(1.7, -1.1, 1.1, 1.7);
    for(int i=0;i<5;i++){
        f += a * n2(p);
        p = m * p + vec2(0.13, 0.19);
        a *= 0.56;
    }
    return f;
}

float ridged(vec2 p){
    float f = 0.0;
    float a = 0.62;
    mat2 m = mat2(1.6, -1.2, 1.2, 1.6);
    for(int i=0;i<4;i++){
        float v = n2(p);
        v = 1.0 - abs(v*2.0 - 1.0);
        f += a * v;
        p = m * p + vec2(0.27, -0.21);
        a *= 0.56;
    }
    return f;
}
